
var g_game = null;

function Game()
{
	this.player1 = null;
	this.player2 = null;

	this.attacker = null;
	this.defender = null;
	this.gear = null;
}